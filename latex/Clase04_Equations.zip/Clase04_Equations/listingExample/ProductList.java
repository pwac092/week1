import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;

public class ProductList {

  public static void main(String[] args) throws Exception {
    Velocity.init();
    Template t = Velocity.getTemplate("./src/calculation.vm");

    VelocityContext ctx = new VelocityContext();

    Collection products = new ArrayList();
    products.add(new Product("Product 1", 12.99));
    products.add(new Product("Product 2", 13.99));
    products.add(new Product("Product 3", 11.99));
    ctx.put("productList", products);

    // calculate total
    Iterator itr = products.iterator();
    double total = 0.00;

    while (itr.hasNext()) {
      Product p = (Product) itr.next();
      total += p.getPrice();
    }

    ctx.put("totalPrice", new Double(total));

    Writer writer = new StringWriter();
    t.merge(ctx, writer);

    System.out.println(writer);
  }
}