/*
 *  The Buckley-Leverett model to solve a two phase flow in porous media
 * 
 * 	> One-dimensional drainage 
 * 	> Homogeneous porous medium
 *  > No source or sink terms
 *  > Horizontal Flow
 *  > Non-compressible flows and solid medium
 * 	
 *  Author: Jhabriel Varela - jhabriel@gmail.com
 *  National University of Asuncion
 *  Scientific & Applied Computing Laboratory
 * 	Date: November 2013
 */

// Headers
#include <iostream>
#include <cmath>
#include <armadillo>		// Linear algebra library

// Namespaces 
using namespace std;
using namespace arma;		// Linear algebra namespace

// Functions
// Effective Saturation
mat effSat (int nOfPoints, mat Sw, double Siw)
{
	mat Swe(nOfPoints,1);	Swe.fill(0);
	for (int j = 0; j <= nOfPoints - 1; j++) {
		Swe(j) = (Sw(j) - Siw) / (1.0 - Siw); }
	return (Swe);
}

// Relative Permeability for Wetting Phase
mat kwett (int nOfPoints, mat Swe, double lambda)
{
	mat krw(nOfPoints,1);	krw.fill(0);
	double pot;		pot = (2+3*lambda)/(lambda);
	for (int j = 0; j <= nOfPoints - 1; j++) {
		krw(j) = pow(Swe(j), pot); }	
	return (krw);
}

// Maximum value of relative permeability for non-wetting phase
double maxkrn (double Siw)
{
	double krnmax;
	krnmax = 1.31 - 2.62 * Siw + 1.1 * Siw * Siw;
	return (krnmax);
}

// Relative permeability for non-wetting phase
mat knonwett (int nOfPoints, mat Swe, double krnmax, double lambda)
{
	mat krn(nOfPoints,1);	krn.fill(0);
	double pot;		pot = (2+lambda)/lambda;
	for (int j = 0; j <= nOfPoints - 1; j++) {
		krn(j) = krnmax * pow((1-Swe(j)),2) * (1-pow(Swe(j),pot));}
	return (krn);
}

// Fractional flow
mat fractflow (int nOfPoints, mat krw, mat krn, double uw, double un)
{
	mat fw(nOfPoints,1);	fw.fill(0);
	for (int j=0; j <= nOfPoints -1; j++)
	{
		fw(j) = 1 / (1+((uw*krn(j))/(un*krw(j))));
	}
	return (fw);
}

// Derivative of fractional flow
mat derfract (int nOfPoints, mat Sw, double Siw, double krnmax, 
			  double uw, double un, double lambda)
{
	double A = Siw;
	double B;	B = (uw * krnmax) / un;
	double L = lambda;
	double N = 2/L;
	double M = 4/L;
	mat dfw(nOfPoints,1);		dfw.fill(0);
	for (int j=0; j <= nOfPoints-1; j++)
	{
	  dfw(j)= ((pow((A-Sw(j)),N)*((2-2*Sw(j))*pow((A-1),N)*pow(A,4)+
	  (3*Sw(j)*Sw(j)+2*Sw(j)-5)*pow((A-1),N)*pow(A,3)+(-9*Sw(j)*Sw(j)
	  +6*Sw(j)+3)*pow((A-1),N)*A*A+(-pow(Sw(j),4)+4*pow(Sw(j),3)+3
	  *Sw(j)*Sw(j)-6*Sw(j))*pow((A-1),N)*A+(pow(Sw(j),4)-4*pow(Sw(j),3)
	  +3*Sw(j)*Sw(j))*pow((A-1),N))+pow((A-Sw(j)),M)*((2*Sw(j)-2)
	  *pow(A,4)+(-6*Sw(j)*Sw(j)+4*Sw(j)+2)*pow(A,3)+(6*pow(Sw(j),3)-6
	  *Sw(j))*A*A+(-2*pow(Sw(j),4)-4*pow(Sw(j),3)+6*Sw(j)*Sw(j))*A+2
	  *pow(Sw(j),4)-2*pow(Sw(j),3)))*B*L+pow((A-Sw(j)),N)*((-2*Sw(j)
	  *Sw(j)+4*Sw(j)-2)*pow((A-1),N)*pow(A,3)+(4*pow(Sw(j),3)-6*Sw(j)
	  *Sw(j)+2)*pow((A-1),N)*A*A+(-2*pow(Sw(j),4)+6*Sw(j)*Sw(j)-4
	  *Sw(j))*pow((A-1),N)*A+(2*pow(Sw(j),4)-4*pow(Sw(j),3)+2*Sw(j)
	  *Sw(j))*pow((A-1),N))*B)/(((pow((A-Sw(j)),N)*((-2*pow(Sw(j),4)
	  +8*pow(Sw(j),3)-12*Sw(j)*Sw(j)+8*Sw(j)-2)*pow((A-1),N)*A*A
	  +(2*pow(Sw(j),5)-6*pow(Sw(j),4)+4*pow(Sw(j),3)+4*Sw(j)
	  *Sw(j)-6*Sw(j)+2)*pow((A-1),N)*A+(-2*pow(Sw(j),5)+8*pow(Sw(j),4)
	  -12*pow(Sw(j),3)+8*Sw(j)*Sw(j)-2*Sw(j))*pow((A-1),N))
	  +pow((A-Sw(j)),M)*((pow(Sw(j),4)-4*pow(Sw(j),3)+6*Sw(j)*Sw(j)-4
	  *Sw(j)+1)*A*A+(-2*pow(Sw(j),5)+8*pow(Sw(j),4)-12*pow(Sw(j),3)+8
	  *Sw(j)*Sw(j)-2*Sw(j))*A+pow(Sw(j),6)-4*pow(Sw(j),5)+6
	  *pow(Sw(j),4)-4*pow(Sw(j),3)+Sw(j)*Sw(j))+(pow(Sw(j),4)-4
	  *pow(Sw(j),3)+6*Sw(j)*Sw(j)-4*Sw(j)+1)*pow((A-1),M)*A*A
	  +(-2*pow(Sw(j),4)+8*pow(Sw(j),3)-12*Sw(j)*Sw(j)+8*Sw(j)-2)
	  *pow((A-1),M)*A+(pow(Sw(j),4)-4*pow(Sw(j),3)+6*Sw(j)
	  *Sw(j)-4*Sw(j)+1)*pow((A-1),M))*B*B+(pow((A-Sw(j)),N)
	  *((2*Sw(j)*Sw(j)-4*Sw(j)+2)*pow((A-1),N)*pow(A,4)
	  +(-6*pow(Sw(j),3)+10*Sw(j)*Sw(j)-2*Sw(j)-2)*pow((A-1),N)
	  *pow(A,3)+(6*pow(Sw(j),4)-6*pow(Sw(j),3)-6*Sw(j)*Sw(j)+6*Sw(j))
	  *pow((A-1),N)*A*A+(-2*pow(Sw(j),5)-2*pow(Sw(j),4)+10*pow(Sw(j),3)
	  -6*Sw(j)*Sw(j))*pow((A-1),N)*A+(2*pow(Sw(j),5)-4*pow(Sw(j),4)+2
	  *pow(Sw(j),3))*pow((A-1),N))+pow((A-Sw(j)),M)*((-2*Sw(j)*Sw(j)+4
	  *Sw(j)-2)*pow(A,4)+(8*pow(Sw(j),3)-16*Sw(j)*Sw(j)+8*Sw(j))
	  *pow(A,3)+(-12*pow(Sw(j),4)+24*pow(Sw(j),3)-12*Sw(j)*Sw(j))*A*A+
	  (8*pow(Sw(j),5)-16*pow(Sw(j),4)+8*pow(Sw(j),3))*A-2*pow(Sw(j),6)
	  +4*pow(Sw(j),5)-2*pow(Sw(j),4)))*B+pow((A-Sw(j)),M)*(pow(A,6)-6
	  *Sw(j)*pow(A,5)+15*Sw(j)*Sw(j)*pow(A,4)-20*pow(Sw(j),3)*pow(A,3)
	  +15*pow(Sw(j),4)*A*A-6*pow(Sw(j),5)*A+pow(Sw(j),6)))*L) ;
	 }
	return (dfw);
}

// Calculus of Swe evaluated in Swf 
double SweEvalSwf (double Swf, double Siw)
{
	double SweSwf;
	SweSwf = (Swf - Siw)/(1 - Siw);
	return (SweSwf);
}

// Calculus of fw evaluated in Swf
double fwEvalSwf (double SweSwf, double krnmax, double uw, double un,
				  double lambda)
{
	double fwSwf;
	double B = (uw*krnmax)/(un);
	double P = (2+lambda)/lambda;
	double R = (2+3*lambda)/lambda;
	fwSwf = 1 / (1 + ((B*pow((1-SweSwf),2)*(1-pow(SweSwf,P))) /
					 pow(SweSwf,R)));	
	return (fwSwf);
}

// Calculus of derivative of fw evaluated in Swf
double dfwEvalSwf (double Swf, double Siw, double krnmax, 
				   double uw, double un, double lambda)
{
	double A = Siw;
	double B = (uw * krnmax) / un;
	double L = lambda;
	double N = 2/L;
	double M = 4/L;
	double dfwSwf;
	  dfwSwf= ((pow((A-Swf),N)*((2-2*Swf)*pow((A-1),N)*pow(A,4)+
	  (3*Swf*Swf+2*Swf-5)*pow((A-1),N)*pow(A,3)+(-9*Swf*Swf
	  +6*Swf+3)*pow((A-1),N)*A*A+(-pow(Swf,4)+4*pow(Swf,3)+3
	  *Swf*Swf-6*Swf)*pow((A-1),N)*A+(pow(Swf,4)-4*pow(Swf,3)
	  +3*Swf*Swf)*pow((A-1),N))+pow((A-Swf),M)*((2*Swf-2)
	  *pow(A,4)+(-6*Swf*Swf+4*Swf+2)*pow(A,3)+(6*pow(Swf,3)-6
	  *Swf)*A*A+(-2*pow(Swf,4)-4*pow(Swf,3)+6*Swf*Swf)*A+2
	  *pow(Swf,4)-2*pow(Swf,3)))*B*L+pow((A-Swf),N)*((-2*Swf
	  *Swf+4*Swf-2)*pow((A-1),N)*pow(A,3)+(4*pow(Swf,3)-6*Swf
	  *Swf+2)*pow((A-1),N)*A*A+(-2*pow(Swf,4)+6*Swf*Swf-4
	  *Swf)*pow((A-1),N)*A+(2*pow(Swf,4)-4*pow(Swf,3)+2*Swf
	  *Swf)*pow((A-1),N))*B)/(((pow((A-Swf),N)*((-2*pow(Swf,4)
	  +8*pow(Swf,3)-12*Swf*Swf+8*Swf-2)*pow((A-1),N)*A*A
	  +(2*pow(Swf,5)-6*pow(Swf,4)+4*pow(Swf,3)+4*Swf
	  *Swf-6*Swf+2)*pow((A-1),N)*A+(-2*pow(Swf,5)+8*pow(Swf,4)
	  -12*pow(Swf,3)+8*Swf*Swf-2*Swf)*pow((A-1),N))
	  +pow((A-Swf),M)*((pow(Swf,4)-4*pow(Swf,3)+6*Swf*Swf-4
	  *Swf+1)*A*A+(-2*pow(Swf,5)+8*pow(Swf,4)-12*pow(Swf,3)+8
	  *Swf*Swf-2*Swf)*A+pow(Swf,6)-4*pow(Swf,5)+6
	  *pow(Swf,4)-4*pow(Swf,3)+Swf*Swf)+(pow(Swf,4)-4
	  *pow(Swf,3)+6*Swf*Swf-4*Swf+1)*pow((A-1),M)*A*A
	  +(-2*pow(Swf,4)+8*pow(Swf,3)-12*Swf*Swf+8*Swf-2)
	  *pow((A-1),M)*A+(pow(Swf,4)-4*pow(Swf,3)+6*Swf
	  *Swf-4*Swf+1)*pow((A-1),M))*B*B+(pow((A-Swf),N)
	  *((2*Swf*Swf-4*Swf+2)*pow((A-1),N)*pow(A,4)
	  +(-6*pow(Swf,3)+10*Swf*Swf-2*Swf-2)*pow((A-1),N)
	  *pow(A,3)+(6*pow(Swf,4)-6*pow(Swf,3)-6*Swf*Swf+6*Swf)
	  *pow((A-1),N)*A*A+(-2*pow(Swf,5)-2*pow(Swf,4)+10*pow(Swf,3)
	  -6*Swf*Swf)*pow((A-1),N)*A+(2*pow(Swf,5)-4*pow(Swf,4)+2
	  *pow(Swf,3))*pow((A-1),N))+pow((A-Swf),M)*((-2*Swf*Swf+4
	  *Swf-2)*pow(A,4)+(8*pow(Swf,3)-16*Swf*Swf+8*Swf)
	  *pow(A,3)+(-12*pow(Swf,4)+24*pow(Swf,3)-12*Swf*Swf)*A*A+
	  (8*pow(Swf,5)-16*pow(Swf,4)+8*pow(Swf,3))*A-2*pow(Swf,6)
	  +4*pow(Swf,5)-2*pow(Swf,4)))*B+pow((A-Swf),M)*(pow(A,6)-6
	  *Swf*pow(A,5)+15*Swf*Swf*pow(A,4)-20*pow(Swf,3)*pow(A,3)
	  +15*pow(Swf,4)*A*A-6*pow(Swf,5)*A+pow(Swf,6)))*L);
	return (dfwSwf);
}
 
// Calculus of the position back and foward of Swf
double posdetdel (int nOfPoints, double Swf, mat Sw)
{
	double bef;
	for (int j=0; j <= nOfPoints-1; j++) {
		if (Sw(j) < Swf)
			bef = j+1; }
	return (bef);
}

// Modification of Sw in order to plot
mat modSw (double nOfPoints, double bef, double Swf, mat Sw)
{
	mat Swdis;		Swdis = Sw;
	Swdis.insert_rows(bef,1);
	Swdis(bef) = Swf;
	Swdis.insert_rows(nOfPoints+1,1);
	Swdis(nOfPoints+1) = 1.0;
	return (Swdis);
}

// Modification of dfw in order to plot 
mat moddfw (double nOfPoints, double bef, double dfwSwf, mat dfw)
{
	mat dfwdis;		dfwdis = dfw;
	dfwdis.insert_rows(bef,1);
	dfwdis(bef) = dfwSwf;
	for (int j=bef; j <= nOfPoints; j++)
	{
		dfwdis(j) = dfwSwf;
	}
	dfwdis.insert_rows(nOfPoints+1,1);
	dfwdis(nOfPoints+1) = dfwSwf;
	return (dfwdis);
}

// Main function
int main()
{
	// Constant declarations
	const double Siw = 0.20;        // Residual water saturation
	mat SiwMat(1,1);				SiwMat(0)	 = Siw;
	const double lambda = 2.0;      // Pores size distribution index
	mat lambdaMat(1,1);				lambdaMat(0) = lambda;
	double krnmax;                  // Maximum value for non-rel.perm.
		
	// Size steps
	int nOfPoints;                  // Number of points  
	double range;                   // Saturation range
	double deltaS;                  // Size step for the saturation
		
	//Carga de viscosidades
	double uw = 1.0;                // Wetting phase viscosity [cP]
	double un = 10.0;               // Non-wetting phase viscosity [cP]
	
	
	// Input of number of points
	cout << "Input the number of points: ";
	cin >> nOfPoints;
	
	ofstream file1;
	file1.open("nOfPoints.txt");
	file1 << nOfPoints;
	file1.close();
	
	// Saturation range for drainage
	range = (1 - Siw);
	
	// Size step for saturation 
	deltaS = range / (nOfPoints -1);
	
	// Creation of Sw
	mat Sw(nOfPoints,1);	Sw.fill(0);
	for (int i = 0; i <= nOfPoints - 1; i++) {
		Sw(i) = Siw + deltaS*(i); }
	
	// Creation of Sn
	mat Sn(nOfPoints,1);	Sn.fill(0);
	Sn = 1 - Sw;
	
	// Determination of krnmax
	krnmax = maxkrn(Siw);
	
	ofstream file2;
	file2.open("krnmax.txt");
	file2 << krnmax;
	file2.close();
	
	// Effective saturation of wetting phase
	mat Swe(nOfPoints,1);   Swe.fill(0);
	Swe = effSat(nOfPoints, Sw, Siw);
	
	// Relative permeability for wetting phase
	mat krw(nOfPoints,1);   krw.fill(0);
	krw = kwett(nOfPoints, Swe, lambda);
	
	// Relative permeability for non-wetting phase
	mat krn(nOfPoints,1);   krn.fill(0);
	krn = knonwett(nOfPoints, Swe, krnmax, lambda);
	
	// Fractional flow for wetting phase
	mat fw(nOfPoints,1);    fw.fill(0);
	fw = fractflow(nOfPoints, krw, krn, uw, un);
	
	// Fractional flow for non-wetting phase
	mat fn(nOfPoints,1);    fn.fill(0);
	fn = 1 - fw;
	
	// Derivative of fractional flow for wetting phase
	mat dfw(nOfPoints,1);   dfw.fill(0);
	dfw = derfract(nOfPoints, Sw, Siw, krnmax, uw, un, lambda);
	
	// Input of Swf
	double Swf;
	cout << "Please input Swf[.39]: ";
	cin >> Swf;		mat Swfmat(1,1);	Swfmat(0) = Swf;	

	// Swe evaluated in Swf
	double SweSwf = SweEvalSwf(Swf,Siw);

	// fw evaluated in Swf
	double fwSwf = fwEvalSwf(SweSwf, krnmax, uw, un, lambda);
	mat fwSwfmat(1,1);	fwSwfmat(0) = fwSwf;
	
	// dfw evaluated in Swf
	double dfwSwf = dfwEvalSwf(Swf, Siw, krnmax, uw, un, lambda);
	mat dfwSwfmat(1,1);	dfwSwfmat(0) = dfwSwf;
	
	// Position back and foward of Sef
	double bef = posdetdel(nOfPoints,Swf,Sw);
	double aft = bef + 1;
	
	cout << "The positions back and foward are: " << bef << " and "
		 << aft << endl;
	
	// Sw modified
	mat Swdis(nOfPoints+2,1);	
	Swdis = modSw(nOfPoints, bef, Swf, Sw);
	
	// dfw modified
	mat dfwdis;					
	dfwdis = moddfw(nOfPoints, bef, dfwSwf, dfw);
	
	// System parameters
	double velTot = 1.0/31530000;       // total darcy vel. [m/s]
	mat matVelTot(1,1);     matVelTot(0) = velTot;
	double Largo  = 1;                  // system length[m]
	mat matLargo(1,1);      matLargo(0) = Largo;
	double Por = .15;                   // rock porosity [-]
	mat matPor(1,1);        matPor(0) = Por;
	double simTime = 3.0000E+06;        // simulation time [s]
	mat matSimTime(1,1);    matSimTime(0) = simTime;	
		
	// Dimensionless time
	double tD = (velTot*simTime)/(Largo*Por);
	
	// Dimensionless position
	mat xD(nOfPoints+2,1);		xD.fill(0);
	
	// Solving the BL equation
	xD = tD * dfwdis;

	// Let's save the vectors in order to plot
	// Swdis.save("output/SwBL10.txt",raw_ascii);
	// xD.save("output/xDBL10.txt",raw_ascii);
		
	return 0;
}
